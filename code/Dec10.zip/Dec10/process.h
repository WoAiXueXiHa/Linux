#include <stdio.h>

void FlushProcess(double total, double cur);
