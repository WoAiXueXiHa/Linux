#include "process.h"
#include "string.h"
#include <unistd.h>

#define NUM 101       // 进度条长度
#define STYLE '*'     // 进度条样式

void FlushProcess(double total, double cur){
  char buffer[NUM] = {0};   
  const char* table = ".....";
  size_t len = strlen(table);
  static int cnt = 0;

  // 计算进度比例
  int rate = (int)(cur*100 / total);
  // 填充进度条
  for(int i = 0; i < rate; i++){
    buffer[i] = STYLE;
  }

  // 打印进度条
  printf("[%-100s][%d%%][%c]\r", buffer, rate, table[cnt%len]);
  fflush(stdout);
  cnt++;
}

