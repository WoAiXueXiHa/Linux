#include "process.h"
#include <unistd.h>
#include <stdlib.h>
#include <time.h>

void Download(){
  int randNum = rand()%10+1; 

  double total = 1024.0;
  double cur = 0.0;
  
  while(cur <= total){
    FlushProcess(total,cur);
    cur += randNum;
    usleep(50000);
   
    if(cur > total){
      cur = 1024.0;
      FlushProcess(total,cur);
      break;
    }
  }
  printf("\n download completely!\n");
}

int main(){
  srand((int)time(NULL));
  Download();
  Download();
  Download();
  return 0;
}


