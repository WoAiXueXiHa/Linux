#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include <stdlib.h>
#include "process.h"

typedef void (*flush_t)(double total, double current);// 这是一个刷新的函数指针类型

const int base = 100;
double total = 2048.0; // 2048MB
double once = 0.1;     // 0.5MB

// 进度条的调用方式
void download(flush_t f)
{
    double current = 0.0;
    while(current < total)
    {
        // 模拟下载行为
        int r = rand() % base + 1; // [1, 10]
        double speed = r * once;
        current += speed;
        if(current >= total) current = total;
        usleep(10000);

        // 更新除了本次新的下载量
        // 根据真实的应用场景，进行动态刷新
        //Process(total, 1.0);
        f(total, current);
        //printf("test: %.1lf/%.1lf\r", current, total);
        //fflush(stdout);
    }
    printf("\n");
}

int main()
{
    srand(time(NULL));
    download(FlushProcess);
    download(FlushProcess);
    download(FlushProcess);
    download(FlushProcess);
    download(FlushProcess);
    download(FlushProcess);
    download(FlushProcess);
    return 0;
}




