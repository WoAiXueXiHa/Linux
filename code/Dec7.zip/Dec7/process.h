#pragma once

//version

//void Process();
//void Process(double total, double current);
void FlushProcess(double total, double current);
