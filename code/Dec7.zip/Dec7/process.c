#include "process.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <string.h>

#define NUM 101
#define STYLE '='
#define POINT '.'
#define SPACE ' '
const int pnum = 6;

// version 2:真实的进度条，应该根据具体的比如下载的量，来动态刷新进度
void FlushProcess(double total, double current)
{
    // 1. 更新当前进度的百分比
    double rate = (current/total)*100;
   // printf("test: %.1lf%%\r", rate);
   // fflush(stdout);
   
   // 2. 更新进度条主体
   char bar[NUM]; // 我们认为，1% 更新一个等号
   memset(bar, '\0', sizeof(bar));
   for(int i = 0; i < (int)rate; i++)
   {
       bar[i] = STYLE;
   }

   // 3. 更新旋转光标或者是其他风格
   static int num = 0;
   num++;
   num%=pnum;

   char points[pnum+1];
   memset(points, '\0', sizeof(points));
   for(int i = 0; i < pnum; i++)
   {
       if(i < num) points[i] = POINT;
       else points[i] = SPACE;
   }

   // 4. test && printf
   printf("[%-100s][%.1lf%%]%s\r", bar, rate, points);
   fflush(stdout);
   //sleep(1);
}

// version 1
//void Process()
//{
//    const char *lable = "|/-\\";
//    int len = strlen(lable);
//    char bar[NUM];
//    memset(bar, '\0', sizeof(bar));
//    int cnt = 0;
//    while(cnt <= 100)
//    {
//        printf("[%-100s][%d%%][%c]\r", bar, cnt, lable[cnt%len]);
//        fflush(stdout);
//        bar[cnt] = STYLE;
//        cnt++;
//        usleep(100000);
//    }
//
//    printf("\r\n");
//}

